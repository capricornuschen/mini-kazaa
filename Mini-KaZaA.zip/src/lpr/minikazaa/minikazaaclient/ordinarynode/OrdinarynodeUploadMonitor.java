

package lpr.minikazaa.minikazaaclient.ordinarynode;

/**
 *
 * @author Andrea Di Grazia, Massimiliano Giovine
 * @date 3-dic-2008
 * @file OrdinarynodeUploadMonitor.java
 */
public class OrdinarynodeUploadMonitor {

}
