

package lpr.minikazaa.util;

/**
 *
 * @author Andrea Di Grazia, Massimiliano Giovine
 * @date 13-nov-2008
 * @file Constants.java
 */
public class Constants {
    public final static int SAVE_EVERYTHING = -45983;
    public final static int MAX_BYTE = 4096;
}
